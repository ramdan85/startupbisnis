-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 14, 2021 at 02:22 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_startup_umi`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_agenda`
--

CREATE TABLE `tbl_agenda` (
  `kd_agenda` int(100) NOT NULL,
  `judul_agenda` varchar(500) NOT NULL,
  `tgl_agenda` varchar(100) NOT NULL,
  `deskripsi_agenda` varchar(1000) NOT NULL,
  `foto` varchar(200) NOT NULL,
  `kondisi` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_agenda`
--

INSERT INTO `tbl_agenda` (`kd_agenda`, `judul_agenda`, `tgl_agenda`, `deskripsi_agenda`, `foto`, `kondisi`) VALUES
(1, 'Pemetaan usaha startup potensial', '2021-11-01', 'Dalam pemetaan usaha startup potensial ini akan dipetakan mana usaha yang berpotensi berkembang, kemudian juga menghadirkan pemateri yang sudah memiliki usaha berkembang untuk memberikan masukan masukan terkait pengembangan usaha.                    ', 'fotoagenda871624271.png', 'Kanan'),
(2, 'Inkubasi bisnis usaha', '2021-11-08', 'Dalam proses inkubasi ini, startup bisnis usaha akan diajarkan bagaimana cara membuat proposal usaha, kemudian bagaimana menjalankan usaha yang baik sehingga melahirkan unit usaha yang mampu bersaing dengan usaha lainnya.                                        ', 'fotoagenda286959198.png', 'Kiri'),
(3, 'Pameran dan Temu Bisnis', '2021-11-30', 'Dalam pameran ini akan ditampilkan digaleri berbasis online produk produk usaha dari startup. Galery pameran ini akan dapat dilihat dan diakses oleh investor diberbagai tempat. Sehingga dengan pameran online ini diharapkan startup dapat memdapatkan mitra usaha untuk bisnis mereka                                        ', 'fotoagenda194963159.png', 'Kanan');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kategori_produk`
--

CREATE TABLE `tbl_kategori_produk` (
  `kd_kategori` int(100) NOT NULL,
  `kategori` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_produk_startup`
--

CREATE TABLE `tbl_produk_startup` (
  `kd_startup` int(100) NOT NULL,
  `kd_produk` varchar(100) NOT NULL,
  `kd_kategori` int(100) NOT NULL,
  `nama_produk` varchar(200) NOT NULL,
  `deskripsi_produk` varchar(1000) NOT NULL,
  `harga_produk` varchar(100) NOT NULL,
  `foto_produk` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_startup`
--

CREATE TABLE `tbl_startup` (
  `kd_startup` int(100) NOT NULL,
  `nama_startup` varchar(500) NOT NULL,
  `deskripsi_startup` varchar(1000) NOT NULL,
  `alamat` varchar(500) NOT NULL,
  `bidang` varchar(200) NOT NULL,
  `website` varchar(100) NOT NULL,
  `media_sosial` varchar(100) NOT NULL,
  `foto` varchar(200) NOT NULL,
  `jenis` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tim_startup`
--

CREATE TABLE `tbl_tim_startup` (
  `kd_startup` int(100) NOT NULL,
  `id` varchar(500) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `alamat` varchar(500) NOT NULL,
  `jabatan` varchar(100) NOT NULL,
  `no_telp` varchar(50) NOT NULL,
  `twiter` varchar(200) NOT NULL,
  `fb` varchar(200) NOT NULL,
  `instagram` varchar(200) NOT NULL,
  `linkedin` varchar(200) NOT NULL,
  `foto` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_usr`
--

CREATE TABLE `tbl_usr` (
  `email` varchar(100) NOT NULL,
  `kunci` varchar(20) NOT NULL,
  `kunci_hash` varchar(1000) NOT NULL,
  `level` varchar(50) NOT NULL,
  `token` varchar(1000) NOT NULL,
  `aktif` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_usr`
--

INSERT INTO `tbl_usr` (`email`, `kunci`, `kunci_hash`, `level`, `token`, `aktif`) VALUES
('ramdanstr@gmail.com', 'abcd123', '$2y$10$CuDRTyC1I3ctK3Y4ZCSiGex5US2oVHrtQxgF1D6hN2dhptarvpq6S', 'admin', 'a1145ac0ef9afac89cde3ccd155e90239200456cc630d67dd85c6f97f63affcd', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_agenda`
--
ALTER TABLE `tbl_agenda`
  ADD PRIMARY KEY (`kd_agenda`);

--
-- Indexes for table `tbl_kategori_produk`
--
ALTER TABLE `tbl_kategori_produk`
  ADD PRIMARY KEY (`kd_kategori`);

--
-- Indexes for table `tbl_startup`
--
ALTER TABLE `tbl_startup`
  ADD PRIMARY KEY (`kd_startup`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_agenda`
--
ALTER TABLE `tbl_agenda`
  MODIFY `kd_agenda` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_kategori_produk`
--
ALTER TABLE `tbl_kategori_produk`
  MODIFY `kd_kategori` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_startup`
--
ALTER TABLE `tbl_startup`
  MODIFY `kd_startup` int(100) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
